<?php
    $path = "/exemple/lab4_6_ex/admin"; //specificam calea spre script
    $fileName = "data/accounts.txt";
?>